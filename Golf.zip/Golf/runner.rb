
require './Game.rb'

#-----------------------------------------------------------------------------
# Test section

#srand(12) # 12 25 51 works

theGame = Game.new
theGame.setup
theGame.run

