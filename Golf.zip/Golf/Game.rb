require "./TextRect.rb"
require "./Report.rb"
require "./Deck.rb"
require "./Tableau.rb"

#==============================================================================
# Class: Game
# The container class for a card game.
#
# Class <Game> supplies an exterior container for all the classes of a card
# game. This allows context to be stored in the container for generic 
# services.

class Game
    
  include Report

  #----------------------------------------------------------------------------
  # Method: initialize
  # Create a new <Game>.
  
  def initialize
    console { 'Welcome to Golf' }
    @deck = Deck.new
  end # initialize
  

  #----------------------------------------------------------------------------
  # Method: setup
  # Set up the initial game conditions.
  
  def setup
    @deck.shuffle
    console('Shuffle the deck.') { @deck.display }
    @firstTab = Tableau::startTableau(@deck)
    console('Game start.') { @firstTab.display }
    @workList = [ @firstTab ]
  end
  

  #----------------------------------------------------------------------------
  # Method: run
  # Run a game of Golf.
  
  def run
    
    console { 'RUNNING' }
    counter = 0
    last    = nil
    
    until @workList.empty? do
      
      if (counter % 101) == 0
        item = @workList.delete_at(rand(@workList.length))
      else
        item = (counter % 2) == 0 ? @workList.shift : @workList.pop
      end
      last = item

      if item.done.length == 52 then
        console('!!! WIN WIN') { item.display }
        exit
      end
     
      next if item.isProcessed
      newItems = item.moveFrom
      
      counter += 1
      if (counter % 100) == 0
        console('Step %d; |Hash| = %d; |WL| = %d' %
                [counter, Tableau::hashPop, @workList.length ]) { item.display }
      end
      
      @workList += newItems
      if (counter % 1001) == 0
        @workList.sort! { |a,b| b <=> a }
      end

    end
      
    console('Last position') { last.display }
      
  end
  
end # Game
