require './Card.rb'

#==============================================================================
# Class: Deck
# A single deck of 52 cards

class Deck

  #============================================================================
  # Section: Private Class Constants
  # Private constants for class <Deck>.

  #----------------------------------------------------------------------------
  # Variable: @@Suit
  # Abbreviations for the suit names
  
  @@Suit = %w{ C D H S }
  
  #----------------------------------------------------------------------------
  # Variable: @@Rank
  # Abbreviations for the ranks.
  
  @@Rank = %w{ A K Q J T 9 8 7 6 5 4 3 2 }
  
  
  def Deck.suit(c)
    c/13
  end
  
  def Deck.rank(c)
    c - (c/13)*13
  end

  def Deck.face(c)
    @@Suit[Deck.suit(c)] + @@Rank[Deck.rank(c)]
  end
  
  def Deck.adjacent?(c1, c2)
    a = c1 - (c1/13)*13
    b = c2 - (c2/13)*13
    x = (a+12) % 13
    y = (a+1)  % 13
    (b == x) || (b == y)
  end

  
  #-----------------------------------------------------------------------------
  # Method: initialize
  # Create a new <Deck> of cards.
  
  def initialize
    @theCards = Array.new(52) { |i| i }
    @available = 0
  end

  #-----------------------------------------------------------------------------
  # Method: deal
  # Deal some cards off the top of the <Deck>.
  
  def deal(n)
    if n > (@theCards.length - @available)
      raise 'Not enough cards: <%d, %d>' % [n, @available]
    end
    cards = @theCards[@available, n]
    @available += n
    cards
  end

 
  #-----------------------------------------------------------------------------
  # Method: display
  # Display a <Deck>.
  #
  # Method <display> creates a <TextRect> that displays a <Deck> in some
  # human readable format.
  #
  # Value:
  #   A <TextRect> containing a display of the <Deck>.
  
  def display
    lines = []
    0.upto(3) do |i|
      line = ''
      0.upto(12) do |j|
        line << Deck.face(@theCards[i*13+j]) << ' '
      end
      lines << line
    end
    lines << 'First available = %d' % @available
    TextRect.new(lines).box!
  end
 
  
  #-----------------------------------------------------------------------------
  # Method: shuffle
  # Shuffle a <Deck> into a new order.
  #
  # Method <shuffle> shuffles a <Deck> into a new order.
  #
  # Effect:
  #   The <Deck> is reordered.
  
  def shuffle
    0.upto(51) do |i|
      r            = rand(52)
      t            = @theCards[i]
      @theCards[i] = @theCards[r]
      @theCards[r] = t
    end
  end

end # Deck
