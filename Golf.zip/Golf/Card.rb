#==============================================================================
# Class: Card
# A single card in a <Deck>.

class Card
  
  attr_reader :rank
  attr_reader :suit
  attr_reader :place
  
  #============================================================================
  # Section: Private Class Constants
  # Private constants for class <Card>.
  
  #----------------------------------------------------------------------------
  # Variable: @@Suit
  # Abbreviations for the suit names
  
  @@Suit = %w{ C D H S }
  
  #----------------------------------------------------------------------------
  # Variable: @@Rank
  # Abbreviations for the ranks.
  
  @@Rank = %w{ A K Q J T 9 8 7 6 5 4 3 2 }
  
  #----------------------------------------------------------------------------
  # Method: initialize
  # Create a new <Card>.
  #
  # Mathod <initialize> creates a new <Card> given its place (that is, an
  # integer from 0 to 51) in the <Deck>.
  #
  # Formal Parameters:
  #   place - an integer from 0 to 51.
  #
  # Effect:
  #   Initalized the <Card>.
  
  def initialize(place)
    @place = place
    @suit  = @place/13
    @rank  = @place - @suit*13
  end

  
  #----------------------------------------------------------------------------
  # Method: display
  # Display a <Card> in SR format.
  
  def display
    @@Suit[@suit] + @@Rank[@rank]
  end
  

  #----------------------------------------------------------------------------
  # Method: adjacent?
  # *TRUE* if two <Cards> are adjacent.
  
  def adjacent?(c)
    return (c.rank == 12 || c.rank == 1) if @rank == 0
    return (c.rank == (@rank - 1)) || (c.rank == (@rank + 1))
  end
  
end # Card
