#==============================================================================
# Class: Tablean
# A tableau for the game of Golf

require './TextRect.rb'
require './Report.rb'
require 'set'

class Tableau
  
  include Report
  
  @@tableauSerial = 0
  @@allTableaues  = Hash.new { |h, k| h[k] = Set.new }
  @@Primes =[  3,   5,   7,  11,  13,  17,  19,  23,  29,  31,
              37,  41,  43,  47,  53,  59,  61,  67,  71,  73,
              79,  83,  89,  97, 101, 103, 107, 109, 113, 127,
             131, 137, 139, 149, 151, 157, 163, 167, 173, 179,
             181, 191, 193, 197, 199, 211, 223, 227, 229, 233,
             239, 241, 251, 257, 263, 269, 271, 277, 281, 283 ]
  
  attr_reader :serial
  attr_reader :isProcessed
  attr_reader :hash
  attr_reader :stacks
  attr_reader :stock
  attr_reader :done
  attr_reader :hash
  
 
  #============================================================================
  # Section: Public Instance Methods
  # Public <Tableau> instance methods.
  
  #----------------------------------------------------------------------------
  # Method: initialize
  # Create a new <Tableau>.
  #
  # Method <initialize> builds a Golf <Tableau> from a specification of the
  # layout.
  #
  # Formal Parameters:
  #   stacks - an *Array* of 7 elements, each an *Array* of <Cards>.
  #   stock  - an *Array* of stock <Cards>.
  #   done   - an *Array* of used <Cards>.
  #   parent - an optional serial number for the parent.
  #
  # Effect:
  #   Initalized the <Tableau>.
  
  def initialize(stacks, stock, done, parent = nil)
    
    @@tableauSerial += 1
    @stacks      = stacks
    @stock       = stock
    @done        = done
    @serial      = @@tableauSerial
    @isProcessed = false
    @parent      = parent.nil? ? 0 : parent
    @hash        = @@Primes[stock.length]*@@Primes[done.length]
    @stacks.each_index { |i| @hash = @hash*@@Primes[stacks[i].length] }
    @hash        = @hash*@@Primes[stock.first] unless stock.empty?
    @hash        = @hash*@@Primes[done.first]  unless done.empty?
    @stacks.each_index do |i|
      @hash = @hash*@@Primes[@stacks[i].last] unless @stacks[i].empty?
    end
    @hash        = @hash % 104395301

  end
 
 
  #----------------------------------------------------------------------------
  # Method: display
  # Display a <Tableau>.
  #
  # Method <display> displays a <Tableau> in human readable form.
  #
  # Value:
  #   A <TextRect> display of a <Tableau>.
  
  def display
        
    banner = 'Serial = %d; ID = %d; processed = %s; hash = %d; parent = %d' %
             [ @serial, object_id, @isProcessed.to_s,
               @hash, @parent ]
    
    # Make up the columns.
    
    columns = @stacks.inject(nil) do |cols, s|
      col = s.inject("Col \n--- \n") do |lines, card|
        lines += (Deck.face(card) + "\n")
      end
      cols.nil? ? TextRect.new(col) : cols.join(TextRect.new(col))
    end
    
    # Now build the stock and the played cards.
    
    stock  = @stock.inject("\nStock:  ") { |s, c| s += (Deck.face(c) + ' ') }
    played = @done.inject("Played: ")    { |s, c| s += (Deck.face(c) + ' ') }
    
    columns.below!(TextRect.new(stock)).below!(TextRect.new(played))
    columns.box!(banner)
    
  end
 
  
  #----------------------------------------------------------------------------
  # Method: moveFrom
  # Enumerate the moves from a <Tableau>.
  
  def moveFrom
    
    value = []
    
    # If possible, move a card from the stock to the done section.
    
    unless @stock.empty? then
      
      # Make the new Tableau by moving the leftmost stock card to the leftmost
      # done card.
      
      top   = @stock[0]
      stock = @stock[1, @stock.length - 1]
      done  = [ top ] + @done
      
      candidate = Tableau.new(@stacks, stock, done, self.serial).findExisting
      value << candidate unless candidate.isProcessed
      
    end
    
    # Now see if the left end of any stack can be moved to the done pile.
    
    unless @done.empty? then
      
      top = @done[0]
      
      @stacks.each_index do |i|
        
        next if @stacks[i].empty?
        next unless Deck.adjacent?(top, @stacks[i][-1])
        
        newStacks = []
        @stacks.each { |s| newStacks << Array.new(s) }
        moved = newStacks[i].pop
        candidate = Tableau.new(newStacks, Array.new(@stock),
                                [moved] + @done, self.serial).findExisting
        value << candidate unless candidate.isProcessed
        
      end
      
    end
    
    @isProcessed = true
    
    return value
    
  end

 
  #----------------------------------------------------------------------------
  # Method: findExisting
  # Find an existing <Tableau> if there is one.
  
  def findExisting
    
    @@allTableaues[@hash].each do |t|
      return t if (t <=> self) == 0
    end
    
    @@allTableaues[@hash].add(self)
    return self
    
  end
  

  #--------------------------------------------------------------------------
  # Method: <=>
  # The "spaceship" comparison
  
  def <=>(other)
    c = @done.length <=> other.done.length
    return c unless c == 0
    c = @stock.length <=> other.stock.length
    return c unless c == 0
    c = @done <=> other.done
    return c unless c == 0
    c = @stock <=> other.stock
    return c unless c == 0
    c = @done <=> other.done
    return c unless c == 0
    stacks.each_index do |i|
      c = @stacks[i] <=> other.stacks[i]
      return c unless c == 0
    end
    return 0
  end

  
  #============================================================================
  # Section: Public Class Methods
  # Public <Tableau> class methods.
  
  #--------------------------------------------------------------------------
  # Method: startTableau
  # Create a starting <Tableau>.
  #
  #
  
  def Tableau::startTableau(deck)
    mine = Tableau.new([deck.deal(5), deck.deal(5), deck.deal(5), deck.deal(5),
                       deck.deal(5), deck.deal(5), deck.deal(5)],
                       deck.deal(17), [])
    @@allTableaues[mine.hash].add(mine)
    return mine
  end


  #--------------------------------------------------------------------------
  # Method: hashPop
  # Population of the <Tableau> *Hash*.
  
  def Tableau::hashPop
    @@allTableaues.length
  end
  
end # Tableau
